public class TravelAndTourismManagement {
    public static void main(String[] args) {

    }
}

